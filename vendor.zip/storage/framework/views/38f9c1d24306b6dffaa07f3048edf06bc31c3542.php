<h1>Product List </h1>
<table border="1">
	<tr>
		<td>ID</td>
		<td>Name</td>
		<td>Price</td>
		<td>Action</td>
	</tr>
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		<td><?php echo e($product['id']); ?></td>
		<td><?php echo e($product['name']); ?></td>
		<td><?php echo e($product['price']); ?></td>
		<td><button>Buy Now</button></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<span><?php echo e($products->links()); ?></span>
<style>
	.w-5{
		display: none;
	}
</style>
<?php /**PATH D:\xampp\htdocs\sumanstech\resources\views/list.blade.php ENDPATH**/ ?>